#ifndef MOTORWIDGET_H
#define MOTORWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QDoubleSpinBox>
#include <QLabel>
#include <QPushButton>
#include <QDebug>

#include "mainthread.h"

class MotorWidget : public QWidget
{
    Q_OBJECT
private:
    QLabel *title_label;
    int _module {1},_axis {1};

    QDoubleSpinBox *value;
    QDoubleSpinBox *freq;

    QLabel *current_postion;

    QString preambule;


public:
    MotorWidget(QString title = "", QWidget *parent = nullptr);
    void setModuleAxis(int module=1,int axis=1){
        _module = module;
        _axis = axis;
        preambule = "M"+QString::number(_module)+"."+QString::number(_axis);
    }


    void setTitle(QString title){title_label->setText(QString("<b>")+title+QString("</b>"));}

public slots:
    void Start(){
        double val = value->value();
        QString str_val;

        if(val>=0){
            str_val = "+"+QString::number(val);
        }else{
            str_val = QString::number(val);
        }

        QString command = preambule+str_val;
        MainThread::ReadWrite(QString(preambule+"P53S0").toUtf8());
        MainThread::ReadWrite(command.toUtf8());
    }

    void Stop(){
        MainThread::ReadWrite(QString(preambule+"SN").toUtf8());
    }

    void setFreq(double value){
        if(!MainThread::serial_port.isOpen()) return;
        QString command = preambule+"P14S"+QString::number(value);
        MainThread::ReadWrite(command.toUtf8());
        qDebug() << "Freq" << value;
    }

    void setCurrentPostion(QString value){
        current_postion->setText(value);
    }
};

#endif // MOTORWIDGET_H
