#include "mainthread.h"

MainThread::MainThread(QWidget *parent) : QThread(parent)
{

}

void MainThread::run(){

    while(1){
        this->msleep(1000);
        if(pause) continue;
        emit updateInformation();
    }

}



