#include "motorwidget.h"

MotorWidget::MotorWidget(QString title, QWidget *parent) : QWidget(parent)
{
    title_label = new QLabel();
    title_label->setAlignment(Qt::AlignHCenter);
    setTitle(title);

    auto layout = new QVBoxLayout();
    this->setLayout(layout);

    layout->addWidget(title_label);

    layout->addWidget(new QLabel("Тек. положение: "));
    current_postion = new QLabel("nan");
    layout->addWidget(current_postion);

    value = new QDoubleSpinBox();
    value->setRange(-999999,999999);
    layout->addWidget(new QLabel("Значение: "));
    layout->addWidget(value);

    auto start_button = new QPushButton("СТАРТ");
    auto stop_button = new QPushButton("СТОП");

    connect(start_button,SIGNAL(clicked()),this,SLOT(Start()));
    connect(stop_button,SIGNAL(clicked()),this,SLOT(Stop()));


    layout->addWidget(start_button);
    layout->addWidget(stop_button);

    freq = new QDoubleSpinBox();
    freq->setRange(0,999999);
    connect(freq,SIGNAL(valueChanged(double)),this,SLOT(setFreq(double)));
    freq->setValue(100);
    layout->addWidget(new QLabel("Частота (P14): "));
    layout->addWidget(freq);

    layout->addStretch();

}
