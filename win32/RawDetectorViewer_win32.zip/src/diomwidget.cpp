#include "diomwidget.h"

DiomWidget::DiomWidget(QString title,QWidget *parent) : QWidget(parent)
{
    title_label = new QLabel();
    title_label->setAlignment(Qt::AlignHCenter);
    setTitle(title);

    auto layout = new QVBoxLayout();
    this->setLayout(layout);

    layout->addWidget(title_label);


    layout->addWidget(new QLabel("входы: "));

    auto input_layout = new QGridLayout();
    layout->addLayout(input_layout);

    for(int i=0;i<8;i+=2){
       inputs.append(new QCheckBox(QString("I")+QString::number(i)));
       inputs.append(new QCheckBox(QString("I")+QString::number(i+1)));
       input_layout->addWidget(inputs.at(i),i/2,0);
       input_layout->addWidget(inputs.at(i+1),i/2,1);
    }

    layout->addWidget(new QLabel("выходы: "));
    auto output_layout = new QGridLayout();
    layout->addLayout(output_layout);

    for(int i=0;i<8;i+=2){
       outputs.append(new QCheckBox(QString("o")+QString::number(i)));
       outputs.append(new QCheckBox(QString("o")+QString::number(i+1)));
       output_layout->addWidget(outputs.at(i),i/2,0);
       output_layout->addWidget(outputs.at(i+1),i/2,1);
    }


    for(auto input : inputs) connect(input,SIGNAL(toggled(bool)),this,SLOT(checked(bool)));


    layout->addStretch();
}

