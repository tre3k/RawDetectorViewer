#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{
    this->setGeometry(0,0,800,600);
    createToolBar();

    serialPortRefresh();

    main_thread = new MainThread(this);
    connect(main_thread,SIGNAL(updateInformation()),this,SLOT(updateInformation()));

    auto central_widget = new QWidget();
    auto central_layout = new QHBoxLayout();
    central_widget->setLayout(central_layout);
    this->setCentralWidget(central_widget);

    DiomWidget *diom_widget = new DiomWidget("DIOM01.1 #1");
    central_layout->addWidget(diom_widget);
    motor_widget1 = new MotorWidget("EXAM01.1 #1.1");
    motor_widget1->setModuleAxis(1,1);
    central_layout->addWidget(motor_widget1);
    motor_widget2 = new MotorWidget("EXAM01.1 #1.2");
    motor_widget2->setModuleAxis(1,2);
    central_layout->addWidget(motor_widget2);
    motor_widget3 = new MotorWidget("EXAM01.1 #1.3");
    motor_widget3->setModuleAxis(1,3);
    central_layout->addWidget(motor_widget3);
    motor_widget4 = new MotorWidget("EXAM01.1 #1.4");
    motor_widget4->setModuleAxis(1,4);
    central_layout->addWidget(motor_widget4);
    motor_widget5 = new MotorWidget("I1AM01.1 #2.1");
    motor_widget5->setModuleAxis(2,1);
    central_layout->addWidget(motor_widget5);
    motor_widget6 = new MotorWidget("I1AM01.1 #3.1");
    motor_widget6->setModuleAxis(3,1);
    central_layout->addWidget(motor_widget6);

    connect(_tool_bar_elements.serial_port_name,SIGNAL(currentTextChanged(QString)),
            this,SLOT(changeSerialPort(QString)));
    changeSerialPort();

    connect(this,SIGNAL(setDiomOutputValue(int)),diom_widget,SLOT(outputFromValue(int)));


    main_thread->start();
}

void MainWindow::createToolBar(){
    _main_tool_bar = new QToolBar();
    this->addToolBar(_main_tool_bar);

    _tool_bar_elements.serial_port_name = new QComboBox();
    _tool_bar_elements.address = new QComboBox();

    _tool_bar_elements.refresh_button = new QPushButton("обн.");

    _main_tool_bar->addWidget(new QLabel(" Устройство: "));
    _main_tool_bar->addWidget(_tool_bar_elements.serial_port_name);

    _main_tool_bar->addWidget(_tool_bar_elements.refresh_button);
    connect(_tool_bar_elements.refresh_button,SIGNAL(clicked()),
            this,SLOT(serialPortRefresh()));

    _main_tool_bar->addWidget(new QLabel(" Адерс: "));
    _main_tool_bar->addWidget(_tool_bar_elements.address);

    _tool_bar_elements.address->addItem("@");
    for(int i=0;i<16;i++){
        if(i<10) _tool_bar_elements.address->addItem(QString::number(i));
        if(i>=10)  _tool_bar_elements.address->addItem(QString(char(i+0x37)));
    }

    connect(_tool_bar_elements.address,SIGNAL(currentTextChanged(QString)),
            this,SLOT(addressChange(QString)));

    _tool_bar_elements.reboot_button = new QPushButton("перезагрузить устройство");
    _main_tool_bar->addSeparator();
    _main_tool_bar->addWidget(_tool_bar_elements.reboot_button);
    connect(_tool_bar_elements.reboot_button,SIGNAL(clicked()),this,SLOT(resetDevice()));
}

void MainWindow::changeSerialPort(QString text){
    MainThread::setSerialPlortName(_tool_bar_elements.serial_port_name->currentText());

}

void MainWindow::updateInformation(){
    if(!MainThread::serial_port.isOpen()) return;
    /* recv information from DIOM and all motors */

    QByteArray resp;

    resp = MainThread::ReadWrite(QString("EG"+QString::number(DIOM_MODULE_NUMBER)+"R").toUtf8());
    emit setDiomOutputValue(QString(MainThread::getValueFromRespon(resp)).toInt());

    resp = MainThread::ReadWrite(QString("M1.1P20R").toUtf8());
    motor_widget1->setCurrentPostion(QString(MainThread::getValueFromRespon(resp)));


    resp = MainThread::ReadWrite(QString("M1.2P20R").toUtf8());
    motor_widget2->setCurrentPostion(QString(MainThread::getValueFromRespon(resp)));


    resp = MainThread::ReadWrite(QString("M1.3P20R").toUtf8());
    motor_widget3->setCurrentPostion(QString(MainThread::getValueFromRespon(resp)));


    resp = MainThread::ReadWrite(QString("M1.4P20R").toUtf8());
    motor_widget4->setCurrentPostion(QString(MainThread::getValueFromRespon(resp)));

    resp = MainThread::ReadWrite(QString("M2.1P20R").toUtf8());
    motor_widget5->setCurrentPostion(QString(MainThread::getValueFromRespon(resp)));


    resp = MainThread::ReadWrite(QString("M3.1P20R").toUtf8());
    motor_widget6->setCurrentPostion(QString(MainThread::getValueFromRespon(resp)));
}

