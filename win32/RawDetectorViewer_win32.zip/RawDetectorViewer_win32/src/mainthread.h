#ifndef MAINTHREAD_H
#define MAINTHREAD_H

#include <QWidget>
#include <QThread>
#include <QSerialPort>
#include <QMessageBox>

#include <QDebug>

#define DIOM_MODULE_NUMBER 1

class MainThread : public QThread
{
    Q_OBJECT
public:
    MainThread(QWidget *parent = nullptr);

    static QSerialPort serial_port;
    static QString serial_port_name;
    static char address;

protected:
    void run();
    bool pause = false;

public:
    static uint16_t checksum(QByteArray message){
        uint16_t retval = address;
        for(int i=0;i<message.size();i++) retval ^= message.at(i);
        retval ^= ':';
        return retval;
    }

     static QByteArray getBuffer(QByteArray message){
        QByteArray buffer;
        buffer.clear();
        buffer.append('\x02');        // <STX>
        buffer.append(address);
        buffer.append(message);
        buffer.append(':');
        buffer.append(QString("%1").arg(checksum(message),2,16,QChar('0')).toUpper());
        buffer.append('\x03');
        return buffer;
    }

    static QByteArray ReadWrite(QByteArray message){
        QByteArray buffer = getBuffer(message);
        QByteArray resp;
        if(!serial_port.isOpen()){
            if(!serial_port.open(QIODevice::ReadWrite)){
                QMessageBox::critical(nullptr,"Error open port","Error open port: "+serial_port_name);
                return nullptr;
            }
            serial_port.setBaudRate(115200);
        }
        serial_port.write(buffer);
        serial_port.waitForBytesWritten(3000);
        serial_port.waitForReadyRead(3000);
        resp = serial_port.readAll();
        //serial_port.close();

        qDebug() << "SEND " << buffer;
        qDebug() << "RECV " << resp;

        return resp;
    }

    static QByteArray getValueFromRespon(QByteArray message){
        QByteArray retval;
        for(auto mess : message){
            if(mess==':') break;
            if(!(mess == '\x02' ||
                 mess == '\x03' ||
                 mess == '\x06' ||
                 mess == '\x15')) retval.append(mess);
        }
        return retval;
    }

    static void setSerialPlortName(QString text){
        serial_port.close();
        serial_port_name = text;
        serial_port.setPortName(text);
    }


public slots:
    void setPause(bool value){pause = value;}

signals:
    void updateInformation();

};


#endif // MAINTHREAD_H
