#include <QApplication>
#include <QSerialPort>

#include "mainthread.h"
#include "mainwindow.h"

/* static variables dicloartion */

QSerialPort MainThread::serial_port;
QString MainThread::serial_port_name;
char MainThread::address = '@';

int main(int argc,char *argv[]){
    QApplication a(argc,argv);

    MainWindow *mw = new MainWindow();
    mw->show();

    return a.exec();
}
