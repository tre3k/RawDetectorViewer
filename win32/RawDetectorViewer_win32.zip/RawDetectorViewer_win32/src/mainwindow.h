#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QToolBar>
#include <QComboBox>
#include <QPushButton>
#include <QLabel>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QHBoxLayout>

#include "mainthread.h"
#include "motorwidget.h"
#include "diomwidget.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);

private:
    QToolBar *_main_tool_bar;
    struct toolBarElements{
        QComboBox *address;
        QPushButton *refresh_button;
        QComboBox *serial_port_name;
        QPushButton *reboot_button;
    } _tool_bar_elements;

    void createToolBar();

    MainThread *main_thread;

    MotorWidget *motor_widget1;
    MotorWidget *motor_widget2;
    MotorWidget *motor_widget3;
    MotorWidget *motor_widget4;
    MotorWidget *motor_widget5;
    MotorWidget *motor_widget6;

signals:
    void setDiomOutputValue(int value);

public slots:
    void serialPortRefresh(){
        _tool_bar_elements.serial_port_name->clear();
        auto serail_info = QSerialPortInfo::availablePorts();
        for(auto info : serail_info) _tool_bar_elements.serial_port_name->addItem(info.portName());

        MainThread::setSerialPlortName(serail_info.at(0).portName());

        MainThread::ReadWrite(QString("M1.1P53S0").toUtf8());
        MainThread::ReadWrite(QString("M1.2P53S0").toUtf8());
        MainThread::ReadWrite(QString("M1.3P53S0").toUtf8());
        MainThread::ReadWrite(QString("M1.4P53S0").toUtf8());
        MainThread::ReadWrite(QString("M2.1P53S0").toUtf8());
        MainThread::ReadWrite(QString("M3.1P53S0").toUtf8());
    }
    void addressChange(QString text){
        MainThread::address = _tool_bar_elements.address->currentText().at(0).toLatin1();
    }

    void changeSerialPort(QString text = "");

    void resetDevice(){
        MainThread::ReadWrite(QString("CR").toUtf8());
    }

    void updateInformation();



};

#endif // MAINWINDOW_H
