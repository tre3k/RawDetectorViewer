#ifndef DIOMWIDGET_H
#define DIOMWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QDoubleSpinBox>
#include <QSpinBox>
#include <QLabel>
#include <QCheckBox>
#include <QFormLayout>

#include <QDebug>

#include "mainthread.h"

class DiomWidget : public QWidget
{
    Q_OBJECT
private:
    QLabel *title_label;

    QList<QCheckBox *> inputs;
    QList<QCheckBox *> outputs;

    int valueFromInput(){
        int retval = 0;

        int i = 0;
        for(auto input : inputs){
            retval |= input->isChecked() ? 1 << i : 0;
            i++;
        }

        return retval;
    }


public:
    explicit DiomWidget(QString title = "", QWidget *parent = nullptr);

    void setTitle(QString title){title_label->setText(QString("<b>")+title+QString("</b>"));}


signals:


public slots:
    void checked(bool value){
        MainThread::ReadWrite(QString("AG"+QString::number(DIOM_MODULE_NUMBER)+"S"+QString::number(valueFromInput())).toUtf8());
    }

    void outputFromValue(int value){
        int i = 0;
        for(auto output : outputs){
            output->setChecked(value & (1 << i) ? true : false);
            i++;
        }

    }

};

#endif // DIOMWIDGET_H
